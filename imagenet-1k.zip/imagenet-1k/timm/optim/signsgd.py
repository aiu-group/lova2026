from __future__ import annotations
from typing import Tuple, Callable

import torch
from torch.optim.optimizer import Optimizer

# functions


def exists(val):
    return val is not None


# class

# @torch.compile(mode="reduce-overhead")
# def update_denominator_(grads, exp_avgs, beta, eps):
#     # This entire block will be flattened into one pass over the VRAM
#     torch._foreach_sub_(grads, exp_avgs)
#     torch._foreach_mul_(grads, grads) # Faster than pow_(2)
#     torch._foreach_mul_(grads, 1 - beta)
#     torch._foreach_addcmul_(grads, exp_avgs, exp_avgs, beta)
#     torch._foreach_sqrt_(grads)
#     torch._foreach_add_(grads, eps)


class SignSGD(Optimizer):
    def __init__(
        self,
        params,
        lr: float = 1e-4,
        betas: Tuple[float, float] = (0.9, 0.99),
        weight_decay: float = 0.0,
        eps: float = 1.0e-8,
    ):
        assert lr > 0.0
        assert all([0.0 <= beta <= 1.0 for beta in betas])
        assert all(
            [
                hasattr(torch, f"_foreach_{attr}_")
                for attr in ("mul", "add", "sign", "lerp")
            ]
        ), "this version of torch does not have the prerequisite foreach functions"

        defaults = dict(lr=lr, betas=betas, weight_decay=weight_decay, eps=eps)

        super(SignSGD, self).__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure: Callable | None = None):

        loss = None
        if exists(closure):
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:

            lr, wd, beta1, beta2, eps = (
                group["lr"],
                group["weight_decay"],
                *group["betas"],
                group["eps"],
            )

            # maybe decoupled weight decay

            # accumulate List[Tensor] for foreach inplace updates

            params = []
            grads = []
            exp_avgs = []

            for p in filter(lambda p: exists(p.grad), group["params"]):

                grad, state = p.grad, self.state[p]

                # init state - exponential moving average of gradient values

                if len(state) == 0:
                    state["exp_avg"] = torch.zeros_like(p)

                exp_avg = state["exp_avg"]

                params.append(p)
                grads.append(grad)
                exp_avgs.append(exp_avg)

            # stepweight decay

            if wd > 0.0:
                torch._foreach_mul_(params, 1.0 - lr * wd)

            # momentum update
            torch._foreach_lerp_(exp_avgs, grads, 1.0 - beta1)

            updates = [t.clone() for t in exp_avgs]
            torch._foreach_sign_(updates)
            torch._foreach_add_(params, updates, alpha=-lr)

        return loss

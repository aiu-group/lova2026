#!/bin/bash
# NUM_PROC=$1
# shift
# torchrun --nproc_per_node=$NUM_PROC train.py "$@"

export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7

torchrun --nproc_per_node=8 --master_port=25278 train.py --data-dir /mnt/data1/public_dataset/imagenet-1k  --model resnet18 --sched cosine --epochs 100 --warmup-epochs 5 --lr 3.0e-4 --batch-size 256 --weight-decay 0.3 --opt lova --opt-betas 0.9 0.99 --smoothing 0.1 --log-wandb --wandb-project lova2026_imagenet1k -j 16 --amp --grad-accum-steps 10 --seed 1

torchrun --nproc_per_node=8 --master_port=25278 train.py --data-dir /mnt/data1/public_dataset/imagenet-1k  --model resnet18 --sched cosine --epochs 100 --warmup-epochs 5 --lr 3.0e-4 --batch-size 256 --weight-decay 0.3 --opt adamw --opt-betas 0.9 0.999 --smoothing 0.1 --log-wandb --wandb-project lova2026_imagenet1k -j 16 --amp --grad-accum-steps 10 --seed 1